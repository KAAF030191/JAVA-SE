package appjfilechooser;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JList;
import java.awt.event.ActionListener;
import java.io.File;
import java.awt.event.ActionEvent;

public class Ventana extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtRutaArchivo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ventana frame = new Ventana();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ventana() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 619, 512);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnSeleccionarArchivo = new JButton("Seleccionar archivo");
		btnSeleccionarArchivo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser chooser=new JFileChooser();
				
				chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
				chooser.setMultiSelectionEnabled(false);
				
				FileNameExtensionFilter filter=new FileNameExtensionFilter("Hojas de estilo", "css", "M�sica MP3", "mp3");
				
				chooser.setFileFilter(filter);
				
				int returnSelection=chooser.showOpenDialog(null);
				
				if(returnSelection==JFileChooser.APPROVE_OPTION)
				{
					txtRutaArchivo.setText(chooser.getSelectedFile().getAbsolutePath());
				}
			}
		});
		btnSeleccionarArchivo.setBounds(12, 13, 159, 25);
		contentPane.add(btnSeleccionarArchivo);
		
		txtRutaArchivo = new JTextField();
		txtRutaArchivo.setBounds(183, 14, 406, 22);
		contentPane.add(txtRutaArchivo);
		txtRutaArchivo.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 89, 577, 130);
		contentPane.add(scrollPane);
		
		JList<String> listaRutaArchivos = new JList<String>();
		scrollPane.setViewportView(listaRutaArchivos);
		
		JButton btnSeleccionarArchivos = new JButton("Seleccionar archivos");
		btnSeleccionarArchivos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser chooser=new JFileChooser();
				
				chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
				chooser.setMultiSelectionEnabled(true);
				
				int returnSelection=chooser.showOpenDialog(null);
				
				if(returnSelection==JFileChooser.APPROVE_OPTION)
				{
					DefaultListModel<String> modelList=new DefaultListModel<String>();
					
					for(File item : chooser.getSelectedFiles())
					{
						modelList.addElement(item.getAbsolutePath());
					}
					
					listaRutaArchivos.setModel(modelList);
				}
			}
		});
		btnSeleccionarArchivos.setBounds(12, 51, 159, 25);
		contentPane.add(btnSeleccionarArchivos);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(12, 278, 577, 174);
		contentPane.add(scrollPane_1);
		
		JList<String> listaRutaArchivosDirectorios = new JList<String>();
		scrollPane_1.setViewportView(listaRutaArchivosDirectorios);
		
		JButton btnListarArchivosDirectorio = new JButton("Listar archivos y directorios");
		btnListarArchivosDirectorio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser chooser=new JFileChooser();
				
				chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				chooser.setMultiSelectionEnabled(false);
				
				int returnSelection=chooser.showOpenDialog(null);
				
				if(returnSelection==JFileChooser.APPROVE_OPTION)
				{
					DefaultListModel<String> modelList=new DefaultListModel<String>();
					
					String rutaAbsolutaDorectorio=chooser.getSelectedFile().getAbsolutePath();
					
					File dir=new File(rutaAbsolutaDorectorio);
					
					for(String item : dir.list())
					{
						modelList.addElement(rutaAbsolutaDorectorio+"/"+item);
					}
					
					listaRutaArchivosDirectorios.setModel(modelList);
				}
			}
		});
		btnListarArchivosDirectorio.setBounds(12, 240, 211, 25);
		contentPane.add(btnListarArchivosDirectorio);
	}
}
