create database dbpersona;
use dbpersona;

create table tpersona
(
idPersona int identity(1,1) not null,
nombre varchar(70) not null,
apellido varchar(40) not null,
documentoIdentidad char(8) not null,
correoElectronico varchar(700) not null,
sexo bit not null,/*1->Masculino, 0->Femenino*/
peso float not null,
dineroObtenido decimal(10,2) not null,
fechaNacimiento date not null,
primary key(idPersona)
);