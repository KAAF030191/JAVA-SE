package appexpresionlambda;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Main {

	public static void main(String[] args)
	{
		int[] numeros={1, 2, 7, 4, 1, 7, 7, 4, 2, 8, 9, 10};
		
		/*for(int item : numeros)
		{
			if(item==7)
			{
				System.out.println(item);
			}
		}*/
		
		/*Arrays.stream(numeros).filter(x -> x==7).forEach(item ->
		{
			System.out.println(item);
		});*/
		
		int[] numerosFiltrados=Arrays.stream(numeros).filter(x -> x==7).toArray();
		
		for(int item : numerosFiltrados)
		{
			System.out.println(item);
		}
		
		System.out.println("........................................");
		
		List<Persona> listPersona=new ArrayList<Persona>();
		
		Persona persona;
		
		persona=new Persona();
		
		persona.setNombre("enlawebdekaaf.blogspot.com");
		persona.setDocumentoIdentidad("12345678");
		persona.setSexo(true);
		
		listPersona.add(persona);
		
		persona=new Persona();
		
		persona.setNombre("enlawebdekaaf.blogspot.com");
		persona.setDocumentoIdentidad("87654321");
		persona.setSexo(true);
		
		listPersona.add(persona);
		
		persona=new Persona();
		
		persona.setNombre("Kevin Arnold");
		persona.setDocumentoIdentidad("77777777");
		persona.setSexo(true);
		
		listPersona.add(persona);
		
		persona=new Persona();
		
		persona.setNombre("Consuelo");
		persona.setDocumentoIdentidad("78787878");
		persona.setSexo(false);
		
		listPersona.add(persona);
		
		persona=new Persona();
		
		persona.setNombre("Maria");
		persona.setDocumentoIdentidad("34536574");
		persona.setSexo(true);
		
		listPersona.add(persona);
		
		persona=new Persona();
		
		persona.setNombre("Maria");
		persona.setDocumentoIdentidad("98986767");
		persona.setSexo(false);
		
		listPersona.add(persona);
		
		/*for(Persona item : listPersona)
		{
			System.out.println(item.getNombre());
		}*/
		
		listPersona.stream().filter(x -> x.getNombre().equals("enlawebdekaaf.blogspot.com")).forEach(item ->
		{
			System.out.println(item.getNombre()+" "+item.getDocumentoIdentidad()+" "+(item.isSexo() ? "Masculino" : "Femenino"));
		});
		
		System.out.println("........................................");
		
		listPersona.stream().filter(x -> !(x.isSexo())).forEach(item ->
		{
			System.out.println(item.getNombre()+" "+item.getDocumentoIdentidad()+" "+(item.isSexo() ? "Masculino" : "Femenino"));
		});
		
		System.out.println("........................................");
		
		listPersona.stream().filter(x -> x.getNombre().equals("Maria") && !(x.isSexo())).forEach(item ->
		{
			System.out.println(item.getNombre()+" "+item.getDocumentoIdentidad()+" "+(item.isSexo() ? "Masculino" : "Femenino"));
		});
		
		System.out.println("........................................");
		
		List<Persona> listPersonaFiltrada=(List<Persona>)listPersona.stream().filter(x -> x.getNombre().equals("enlawebdekaaf.blogspot.com")).collect(Collectors.toList());
		
		for(Persona item : listPersonaFiltrada)
		{
			System.out.println(item.getNombre()+" "+item.getDocumentoIdentidad()+" "+(item.isSexo() ? "Masculino" : "Femenino"));
		}
	}
}