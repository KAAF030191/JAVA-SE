package app.enlawebdekaaf;

import java.awt.Dimension;
import java.awt.Toolkit;

import app.enlawebdekaaf.ui.Ventana;

public class Main {

	public static void main(String[] args) 
	{
		Ventana x=new Ventana();
		
		Dimension dimensionPantalla=Toolkit.getDefaultToolkit().getScreenSize();
		Dimension dimensionVentana=x.getSize();
		
		x.setLocation((dimensionPantalla.width-dimensionVentana.width)/2, (dimensionPantalla.height-dimensionVentana.height)/2);
		
		x.setVisible(true);
	}
}