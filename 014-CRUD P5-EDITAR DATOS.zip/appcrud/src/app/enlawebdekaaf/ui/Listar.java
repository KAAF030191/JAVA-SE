package app.enlawebdekaaf.ui;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.List;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import app.enlawebdekaaf.business.Persona;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.math.BigDecimal;
import java.sql.Date;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Listar extends JInternalFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTable tablePersona;
	private JTextField txtNombre;
	private JTextField txtApellido;
	private JTextField txtDocumentoIdentidad;
	private JTextField txtCorreoElectronico;
	private JTextField txtPeso;
	private JTextField txtDineroObtenido;
	private JTextField dateFechaNacimiento;
	private JRadioButton radioMasculino;
	private JRadioButton radioFemenino;
	private final ButtonGroup buttonGroupSexo = new ButtonGroup();
	private JTextField txtIdPersona;

	/**
	 * Create the frame.
	 */
	public Listar() {
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);
		setBounds(100, 100, 676, 600);
		getContentPane().setLayout(null);
		
		JLabel lblListaDePersonas = new JLabel("Lista de personas");
		lblListaDePersonas.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblListaDePersonas.setBounds(12, 13, 636, 38);
		getContentPane().add(lblListaDePersonas);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 64, 636, 175);
		getContentPane().add(scrollPane);
		
		tablePersona = new JTable();
		tablePersona.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent arg0) {
				if(tablePersona.getSelectedRow()>-1)
				{
					txtIdPersona.setText(tablePersona.getValueAt(tablePersona.getSelectedRow(), 0).toString());
					txtNombre.setText(tablePersona.getValueAt(tablePersona.getSelectedRow(), 1).toString());
					txtApellido.setText(tablePersona.getValueAt(tablePersona.getSelectedRow(), 2).toString());
					txtDocumentoIdentidad.setText(tablePersona.getValueAt(tablePersona.getSelectedRow(), 3).toString());
					txtCorreoElectronico.setText(tablePersona.getValueAt(tablePersona.getSelectedRow(), 4).toString());
					
					boolean sexo=tablePersona.getValueAt(tablePersona.getSelectedRow(), 5).toString()=="true" ? true : false;
					
					if(sexo)
					{
						radioMasculino.setSelected(true);
					}
					else
					{
						radioFemenino.setSelected(true);
					}
					
					txtPeso.setText(tablePersona.getValueAt(tablePersona.getSelectedRow(), 6).toString());
					txtDineroObtenido.setText(tablePersona.getValueAt(tablePersona.getSelectedRow(), 7).toString());
					dateFechaNacimiento.setText(tablePersona.getValueAt(tablePersona.getSelectedRow(), 8).toString());
				}
			}
		});
		scrollPane.setViewportView(tablePersona);
		
		Persona persona=new Persona();
		
		List<Object[]> listaPersona=persona.Listar();
		
		DefaultTableModel tableModel=new DefaultTableModel(new Object[]
		{
			"Codigo",
			"Nombre",
			"Apellido",
			"Documetno de identidad",
			"Correo",
			"Sexo",
			"Peso",
			"Dinero obtenido",
			"Fecha de nacimiento"
		}, 0);
		
		for(Object[] item : listaPersona)
		{
			tableModel.addRow(item);
		}
		
		tablePersona.setModel(tableModel);
		
		JLabel lblEditarDatos = new JLabel("Editar datos");
		lblEditarDatos.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEditarDatos.setBounds(12, 252, 145, 27);
		getContentPane().add(lblEditarDatos);
		
		JLabel label_1 = new JLabel("Nombre");
		label_1.setBounds(12, 292, 145, 16);
		getContentPane().add(label_1);
		
		txtNombre = new JTextField();
		txtNombre.setColumns(10);
		txtNombre.setBounds(169, 289, 479, 22);
		getContentPane().add(txtNombre);
		
		JLabel label_2 = new JLabel("Apellido");
		label_2.setBounds(12, 321, 145, 16);
		getContentPane().add(label_2);
		
		txtApellido = new JTextField();
		txtApellido.setColumns(10);
		txtApellido.setBounds(169, 318, 479, 22);
		getContentPane().add(txtApellido);
		
		JLabel label_3 = new JLabel("Documento de identidad");
		label_3.setBounds(12, 350, 145, 16);
		getContentPane().add(label_3);
		
		txtDocumentoIdentidad = new JTextField();
		txtDocumentoIdentidad.setColumns(10);
		txtDocumentoIdentidad.setBounds(169, 347, 479, 22);
		getContentPane().add(txtDocumentoIdentidad);
		
		JLabel label_4 = new JLabel("Correo electr\u00F3nico");
		label_4.setBounds(12, 379, 145, 16);
		getContentPane().add(label_4);
		
		txtCorreoElectronico = new JTextField();
		txtCorreoElectronico.setColumns(10);
		txtCorreoElectronico.setBounds(169, 376, 479, 22);
		getContentPane().add(txtCorreoElectronico);
		
		JLabel label_5 = new JLabel("Sexo");
		label_5.setBounds(12, 408, 145, 16);
		getContentPane().add(label_5);
		
		radioMasculino = new JRadioButton("Masculino");
		buttonGroupSexo.add(radioMasculino);
		radioMasculino.setSelected(true);
		radioMasculino.setBounds(169, 404, 112, 25);
		getContentPane().add(radioMasculino);
		
		radioFemenino = new JRadioButton("Femenino");
		buttonGroupSexo.add(radioFemenino);
		radioFemenino.setBounds(285, 404, 112, 25);
		getContentPane().add(radioFemenino);
		
		txtPeso = new JTextField();
		txtPeso.setColumns(10);
		txtPeso.setBounds(169, 434, 479, 22);
		getContentPane().add(txtPeso);
		
		JLabel label_6 = new JLabel("Peso");
		label_6.setBounds(12, 437, 145, 16);
		getContentPane().add(label_6);
		
		JLabel label_7 = new JLabel("Dinero obtenido");
		label_7.setBounds(12, 466, 145, 16);
		getContentPane().add(label_7);
		
		txtDineroObtenido = new JTextField();
		txtDineroObtenido.setColumns(10);
		txtDineroObtenido.setBounds(169, 463, 479, 22);
		getContentPane().add(txtDineroObtenido);
		
		dateFechaNacimiento = new JTextField();
		dateFechaNacimiento.setColumns(10);
		dateFechaNacimiento.setBounds(169, 492, 479, 22);
		getContentPane().add(dateFechaNacimiento);
		
		JLabel label_8 = new JLabel("Fecha de nacimiento");
		label_8.setBounds(12, 495, 145, 16);
		getContentPane().add(label_8);
		
		JButton btnGuardarDatos = new JButton("Guardar datos");
		btnGuardarDatos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int idPersona;
				String nombre;
				String apellido;
				String documentoIdentidad;
				String correoElectronico;
				boolean sexo=false;
				float peso;
				BigDecimal dineroObtenido;
				Date fechaNacimiento;
				
				idPersona=Integer.parseInt(txtIdPersona.getText());
				nombre=txtNombre.getText();
				apellido=txtApellido.getText();
				documentoIdentidad=txtDocumentoIdentidad.getText();
				correoElectronico=txtCorreoElectronico.getText();
				
				Enumeration<AbstractButton> abstractRadioButtonSexo=buttonGroupSexo.getElements();
				
				while(abstractRadioButtonSexo.hasMoreElements())
				{
					AbstractButton abstractButton=(AbstractButton) abstractRadioButtonSexo.nextElement();
					
					if(abstractButton.isSelected())
					{
						sexo=(abstractButton.getText()=="Masculino" ? true : false);
						
						break;
					}
				}
				
				peso=Float.parseFloat(txtPeso.getText());
				dineroObtenido=new BigDecimal(txtDineroObtenido.getText());
				
				Calendar calendar=Calendar.getInstance();
				
				calendar.set(Integer.parseInt(dateFechaNacimiento.getText().split("-")[0]), Integer.parseInt(dateFechaNacimiento.getText().split("-")[1])-1, Integer.parseInt(dateFechaNacimiento.getText().split("-")[2]));
				
				fechaNacimiento=new Date(calendar.getTime().getTime());
				
				Persona persona=new Persona();
				
				if(persona.Editar(idPersona, nombre, apellido, documentoIdentidad, correoElectronico, sexo, peso, dineroObtenido, fechaNacimiento))
				{
					JOptionPane.showMessageDialog(null, "Datos guardados correctamente", "Correcto", JOptionPane.INFORMATION_MESSAGE);
					
					List<Object[]> listaPersona=persona.Listar();
					
					DefaultTableModel tableModel=new DefaultTableModel(new Object[]
					{
						"Codigo",
						"Nombre",
						"Apellido",
						"Documetno de identidad",
						"Correo",
						"Sexo",
						"Peso",
						"Dinero obtenido",
						"Fecha de nacimiento"
					}, 0);
					
					for(Object[] item : listaPersona)
					{
						tableModel.addRow(item);
					}
					
					tablePersona.setModel(tableModel);
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Error en la ejecuci�n", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnGuardarDatos.setBounds(482, 527, 166, 25);
		getContentPane().add(btnGuardarDatos);
		
		txtIdPersona = new JTextField();
		txtIdPersona.setEditable(false);
		txtIdPersona.setBounds(169, 256, 250, 22);
		getContentPane().add(txtIdPersona);
		txtIdPersona.setColumns(10);
	}
}
