package app.enlawebdekaaf.main;

import app.enlawebdekaaf.ui.MDI;

public class Main
{
	public static void main(String[] args)
	{
		MDI mdiPrincipal=new MDI();
		
		mdiPrincipal.setVisible(true);
	}
}