package app.enlawebdekaaf.conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class Conexion
{
	public static Connection getConnection()
	{
		Connection connection=null;
		String databaseName="dbpersona";
		String user="sa";
		String password="030191";
		
		try
		{
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			String connectionString="jdbc:sqlserver://localhost;databaseName="+databaseName+";user="+user+";password="+password+";";
			connection=DriverManager.getConnection(connectionString);
		}
		catch(ClassNotFoundException ex)
		{
			JOptionPane.showMessageDialog(null, ex.getMessage(), "Excepci�n", JOptionPane.ERROR_MESSAGE);
			
			connection=null;
		}
		catch(SQLException ex)
		{
			JOptionPane.showMessageDialog(null, ex.getMessage(), "Excepci�n", JOptionPane.ERROR_MESSAGE);
			
			connection=null;
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null, ex.getMessage(), "Excepci�n", JOptionPane.ERROR_MESSAGE);
			
			connection=null;
		}
		
		return connection;
	}
}