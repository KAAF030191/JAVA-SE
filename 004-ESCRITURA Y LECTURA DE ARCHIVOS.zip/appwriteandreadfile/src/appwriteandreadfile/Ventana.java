package appwriteandreadfile;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.awt.event.ActionEvent;

public class Ventana extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ventana frame = new Ventana();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ventana() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTextoAEscribir = new JLabel("Texto a escribir");
		lblTextoAEscribir.setBounds(12, 49, 112, 16);
		contentPane.add(lblTextoAEscribir);
		
		JTextArea txtTextoEscribir = new JTextArea();
		txtTextoEscribir.setBounds(136, 13, 284, 89);
		contentPane.add(txtTextoEscribir);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(12, 153, 408, 2);
		contentPane.add(separator);
		
		JTextArea txtDatosArchivo = new JTextArea();
		txtDatosArchivo.setEditable(false);
		txtDatosArchivo.setBounds(12, 206, 408, 184);
		contentPane.add(txtDatosArchivo);
		
		JButton btnEscribir = new JButton("Escribir");
		btnEscribir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				FileWriter fileWriter=null;
				PrintWriter printWriter=null;
				String rutaArchivo="C:\\Users\\KAAF0\\workspace\\appwriteandreadfile\\archivo\\miArchivo.txt";
				
				try
				{					
					fileWriter=new FileWriter(rutaArchivo, true);
					
					printWriter=new PrintWriter(fileWriter);
					
					printWriter.println(txtTextoEscribir.getText());
					
					txtTextoEscribir.setText("");
					
					JOptionPane.showMessageDialog(null, "Texto agregado correctamente al archivo.", "Correcto", JOptionPane.INFORMATION_MESSAGE);
				}
				catch(Exception ex)
				{
					JOptionPane.showConfirmDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
				finally
				{
					if(printWriter!=null)
					{
						printWriter.close();
					}
					
					if(fileWriter!=null)
					{
						try
						{
							fileWriter.close();
						}
						catch(Exception ex)
						{
							JOptionPane.showConfirmDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
						}
					}
				}
			}
		});
		btnEscribir.setBounds(323, 115, 97, 25);
		contentPane.add(btnEscribir);
		
		JButton btnMostrarDatosDel = new JButton("Mostrar datos del archivo");
		btnMostrarDatosDel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				File file=null;
				FileReader fileReader=null;
				BufferedReader bufferedReader=null;
				String rutaArchivo="C:\\Users\\KAAF0\\workspace\\appwriteandreadfile\\archivo\\miArchivo.txt";
				
				try
				{
					file=new File(rutaArchivo);
					
					fileReader=new FileReader(file);
					
					String linea=null;
					
					bufferedReader=new BufferedReader(fileReader);
					
					txtDatosArchivo.setText("");
					
					while((linea=bufferedReader.readLine())!=null)
					{
						txtDatosArchivo.append(linea);
						txtDatosArchivo.append("\n");
					}
				}
				catch(Exception ex)
				{
					JOptionPane.showConfirmDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
				finally
				{
					if(fileReader!=null)
					{
						try
						{
							fileReader.close();
						}
						catch(Exception ex)
						{
							JOptionPane.showConfirmDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
						}
					}
				}
			}
		});
		btnMostrarDatosDel.setBounds(12, 168, 197, 25);
		contentPane.add(btnMostrarDatosDel);
	}
}
