package app.enlawebdekaaf.business;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import app.enlawebdekaaf.conexion.Conexion;

public class Persona
{
	public boolean Insertar(String nombre, String apellido, String documentoIdentidad, String correoElectronico, boolean sexo, float peso, BigDecimal dineroObtenido, Date fechaNacimiento)
	{
		boolean varOut=false;
		Connection connection=null;
		PreparedStatement ps=null;
		
		try
		{
			connection=Conexion.getConnection();
			
			ps=connection.prepareStatement("insert into tpersona(nombre, apellido, documentoIdentidad, correoElectronico, sexo, peso, dineroObtenido, fechaNacimiento) values(?, ?, ?, ?, ?, ?, ?, ?)");
			
			ps.setString(1, nombre);
			ps.setString(2, apellido);
			ps.setString(3, documentoIdentidad);
			ps.setString(4, correoElectronico);
			ps.setBoolean(5, sexo);
			ps.setFloat(6, peso);
			ps.setBigDecimal(7, dineroObtenido);
			ps.setDate(8, fechaNacimiento);
			
			ps.execute();
			
			varOut=true;
		}
		catch(Exception ex)
		{
			varOut=false;
			
			System.out.println(ex.getMessage());
		}
		finally
		{
			try
			{
				if(ps!=null)
				{
					ps.close();
				}
				
				if(connection!=null)
				{
					connection.close();
				}
			}
			catch(Exception ex)
			{
				System.out.println(ex.getMessage());
			}
		}
		
		return varOut;
	}
	
	public List<Object[]> Listar()
	{
		List<Object[]> listaPersona=null;
		Connection connection=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try
		{
			connection=Conexion.getConnection();
			
			ps=connection.prepareStatement("select * from tpersona");
			
			rs=ps.executeQuery();
			
			listaPersona=new ArrayList<Object[]>();
			
			while(rs.next())
			{
				Object[] objPersona=
				{
					rs.getString("nombre"),
					rs.getString("apellido"),
					rs.getString("documentoIdentidad"),
					rs.getString("correoElectronico"),
					rs.getBoolean("sexo"),
					rs.getFloat("peso"),
					rs.getBigDecimal("dineroObtenido"),
					rs.getDate("fechaNacimiento")
				};
				
				listaPersona.add(objPersona);
			}
		}
		catch(Exception ex)
		{
			listaPersona=null;
			
			System.out.println(ex.getMessage());
		}
		finally
		{
			try
			{
				if(rs!=null)
				{
					rs.close();
				}
				
				if(ps!=null)
				{
					ps.close();
				}
				
				if(connection!=null)
				{
					connection.close();
				}
			}
			catch(Exception ex)
			{
				System.out.println(ex.getMessage());
			}
		}
		
		return listaPersona;
	}
}