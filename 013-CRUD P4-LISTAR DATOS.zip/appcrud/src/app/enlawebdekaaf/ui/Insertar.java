package app.enlawebdekaaf.ui;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JSeparator;
import javax.swing.JTextField;

import app.enlawebdekaaf.business.Persona;

import javax.swing.JRadioButton;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.Calendar;
import java.util.Enumeration;
import java.awt.event.ActionEvent;

public class Insertar extends JInternalFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField txtNombre;
	private JTextField txtApellido;
	private JTextField txtDocumentoIdentidad;
	private JTextField txtCorreoElectronico;
	private JTextField txtPeso;
	private JTextField txtDineroObtenido;
	private JTextField txtFechaNacimiento;
	private final ButtonGroup buttonGroupSexo = new ButtonGroup();

	/**
	 * Create the frame.
	 */
	public Insertar() {
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);
		setBounds(100, 100, 450, 362);
		getContentPane().setLayout(null);
		
		JLabel lblInsertarDatos = new JLabel("Insertar datos");
		lblInsertarDatos.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblInsertarDatos.setBounds(12, 13, 410, 27);
		getContentPane().add(lblInsertarDatos);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(12, 38, 410, 2);
		getContentPane().add(separator);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setBounds(12, 53, 145, 16);
		getContentPane().add(lblNombre);
		
		JLabel lblApellido = new JLabel("Apellido");
		lblApellido.setBounds(12, 82, 145, 16);
		getContentPane().add(lblApellido);
		
		JLabel lblDocumentoDeIdentidad = new JLabel("Documento de identidad");
		lblDocumentoDeIdentidad.setBounds(12, 111, 145, 16);
		getContentPane().add(lblDocumentoDeIdentidad);
		
		JLabel lblCorreoElectrnico = new JLabel("Correo electr\u00F3nico");
		lblCorreoElectrnico.setBounds(12, 140, 145, 16);
		getContentPane().add(lblCorreoElectrnico);
		
		JLabel lblSexo = new JLabel("Sexo");
		lblSexo.setBounds(12, 169, 145, 16);
		getContentPane().add(lblSexo);
		
		JLabel lblPeso = new JLabel("Peso");
		lblPeso.setBounds(12, 198, 145, 16);
		getContentPane().add(lblPeso);
		
		JLabel lblDineroObtenido = new JLabel("Dinero obtenido");
		lblDineroObtenido.setBounds(12, 227, 145, 16);
		getContentPane().add(lblDineroObtenido);
		
		JLabel lblFechaDeNacimiento = new JLabel("Fecha de nacimiento");
		lblFechaDeNacimiento.setBounds(12, 256, 145, 16);
		getContentPane().add(lblFechaDeNacimiento);
		
		txtNombre = new JTextField();
		txtNombre.setBounds(169, 50, 253, 22);
		getContentPane().add(txtNombre);
		txtNombre.setColumns(10);
		
		txtApellido = new JTextField();
		txtApellido.setColumns(10);
		txtApellido.setBounds(169, 79, 253, 22);
		getContentPane().add(txtApellido);
		
		txtDocumentoIdentidad = new JTextField();
		txtDocumentoIdentidad.setColumns(10);
		txtDocumentoIdentidad.setBounds(169, 108, 253, 22);
		getContentPane().add(txtDocumentoIdentidad);
		
		txtCorreoElectronico = new JTextField();
		txtCorreoElectronico.setColumns(10);
		txtCorreoElectronico.setBounds(169, 137, 253, 22);
		getContentPane().add(txtCorreoElectronico);
		
		txtPeso = new JTextField();
		txtPeso.setColumns(10);
		txtPeso.setBounds(169, 195, 253, 22);
		getContentPane().add(txtPeso);
		
		txtDineroObtenido = new JTextField();
		txtDineroObtenido.setColumns(10);
		txtDineroObtenido.setBounds(169, 224, 253, 22);
		getContentPane().add(txtDineroObtenido);
		
		txtFechaNacimiento = new JTextField();
		txtFechaNacimiento.setColumns(10);
		txtFechaNacimiento.setBounds(169, 253, 253, 22);
		getContentPane().add(txtFechaNacimiento);
		
		JRadioButton radioMasculino = new JRadioButton("Masculino");
		buttonGroupSexo.add(radioMasculino);
		radioMasculino.setSelected(true);
		radioMasculino.setBounds(169, 165, 112, 25);
		getContentPane().add(radioMasculino);
		
		JRadioButton radioFemenino = new JRadioButton("Femenino");
		buttonGroupSexo.add(radioFemenino);
		radioFemenino.setBounds(285, 165, 112, 25);
		getContentPane().add(radioFemenino);
		
		JButton btnGuardarDatos = new JButton("Guardar datos");
		btnGuardarDatos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String nombre;
				String apellido;
				String documentoIdentidad;
				String correoElectronico;
				boolean sexo=false;
				float peso;
				BigDecimal dineroObtenido;
				Date fechaNacimiento;
				
				nombre=txtNombre.getText();
				apellido=txtApellido.getText();
				documentoIdentidad=txtDocumentoIdentidad.getText();
				correoElectronico=txtCorreoElectronico.getText();
				
				Enumeration<AbstractButton> abstractRadioButtonSexo=buttonGroupSexo.getElements();
				
				while(abstractRadioButtonSexo.hasMoreElements())
				{
					AbstractButton abstractButton=(AbstractButton) abstractRadioButtonSexo.nextElement();
					
					if(abstractButton.isSelected())
					{
						sexo=(abstractButton.getText()=="Masculino" ? true : false);
						
						break;
					}
				}
				
				peso=Float.parseFloat(txtPeso.getText());
				dineroObtenido=new BigDecimal(txtDineroObtenido.getText());
				
				Calendar calendar=Calendar.getInstance();
				
				calendar.set(Integer.parseInt(txtFechaNacimiento.getText().split("-")[0]), Integer.parseInt(txtFechaNacimiento.getText().split("-")[1])-1, Integer.parseInt(txtFechaNacimiento.getText().split("-")[2]));
				
				fechaNacimiento=new Date(calendar.getTime().getTime());
				
				Persona persona=new Persona();
				
				if(persona.Insertar(nombre, apellido, documentoIdentidad, correoElectronico, sexo, peso, dineroObtenido, fechaNacimiento))
				{
					JOptionPane.showMessageDialog(null, "Registro realizado correctamente", "Correcto", JOptionPane.INFORMATION_MESSAGE);
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Error en la ejecuci�n", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnGuardarDatos.setBounds(256, 288, 166, 25);
		getContentPane().add(btnGuardarDatos);

	}
}
