package app.enlawebdekaaf.ui;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.util.List;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import app.enlawebdekaaf.business.Persona;

public class Listar extends JInternalFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTable tablePersona;

	/**
	 * Create the frame.
	 */
	public Listar() {
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);
		setBounds(100, 100, 676, 367);
		getContentPane().setLayout(null);
		
		JLabel lblListaDePersonas = new JLabel("Lista de personas");
		lblListaDePersonas.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblListaDePersonas.setBounds(12, 13, 636, 38);
		getContentPane().add(lblListaDePersonas);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 64, 636, 254);
		getContentPane().add(scrollPane);
		
		tablePersona = new JTable();
		scrollPane.setViewportView(tablePersona);
		
		Persona persona=new Persona();
		
		List<Object[]> listaPersona=persona.Listar();
		
		DefaultTableModel tableModel=new DefaultTableModel(new Object[]
		{
			"Nombre",
			"Apellido",
			"Documetno de identidad",
			"Correo",
			"Sexo",
			"Peso",
			"Dinero obtenido",
			"Fecha de nacimiento"
		}, 0);
		
		for(Object[] item : listaPersona)
		{
			tableModel.addRow(item);
		}
		
		tablePersona.setModel(tableModel);
	}
}
