package app.enlawebdekaaf.ui;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.CardLayout;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JDesktopPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MDI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JDesktopPane desktopPane;

	/**
	 * Create the frame.
	 */
	public MDI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 971, 497);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("Archivo");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmInsertarPersona = new JMenuItem("Insertar persona");
		mntmInsertarPersona.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Insertar frmInsertar=new Insertar();
				
				desktopPane.add(frmInsertar);
				
				frmInsertar.setVisible(true);
			}
		});
		mnNewMenu.add(mntmInsertarPersona);
		
		JMenuItem mntmListarPersonas = new JMenuItem("Listar personas");
		mntmListarPersonas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Listar frmListar=new Listar();
				
				desktopPane.add(frmListar);
				
				frmListar.setVisible(true);
			}
		});
		mnNewMenu.add(mntmListarPersonas);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(new CardLayout(0, 0));
		
		desktopPane = new JDesktopPane();
		contentPane.add(desktopPane, "name_2635578465456");
	}
}
