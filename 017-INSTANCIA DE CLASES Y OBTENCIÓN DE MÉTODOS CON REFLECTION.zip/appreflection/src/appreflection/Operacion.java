package appreflection;

public class Operacion
{
	public void Saludar()
	{
		System.out.println("Hola desde enlawebdekaaf");
	}
	
	public void Saludar(String nombre)
	{
		System.out.println("Hola "+nombre);
	}
	
	public String MiMetodo()
	{
		return "Texto retornado";
	}
	
	public int Sumar(int x, int y)
	{
		return x+y;
	}
	
	@SuppressWarnings("unused")
	private String MetodoPrivadio()
	{
		return "M�todo privado";
	}
}