package appexpresionesregulares;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Ventana extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtDocumentoIdentidad;
	private JTextField txtCorreoElectronico;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ventana frame = new Ventana();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ventana() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 463, 123);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblDocumentoIdentidad = new JLabel("Documento identidad");
		lblDocumentoIdentidad.setBounds(12, 13, 134, 16);
		contentPane.add(lblDocumentoIdentidad);
		
		JLabel lblCorreoElectrnico = new JLabel("Correo electr\u00F3nico");
		lblCorreoElectrnico.setBounds(12, 42, 134, 16);
		contentPane.add(lblCorreoElectrnico);
		
		txtDocumentoIdentidad = new JTextField();
		txtDocumentoIdentidad.setBounds(158, 10, 161, 22);
		contentPane.add(txtDocumentoIdentidad);
		txtDocumentoIdentidad.setColumns(10);
		
		txtCorreoElectronico = new JTextField();
		txtCorreoElectronico.setColumns(10);
		txtCorreoElectronico.setBounds(158, 39, 161, 22);
		contentPane.add(txtCorreoElectronico);
		
		JButton btnValidarDocumentoIdentidad = new JButton("Validar");
		btnValidarDocumentoIdentidad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String documentoIdentidad=txtDocumentoIdentidad.getText();
				//78789898, 12345635
				String expresionDocumentoIdentidad="[1-9]{1}[0-9]{7}";
				
				if(documentoIdentidad.matches(expresionDocumentoIdentidad))
				{
					JOptionPane.showMessageDialog(null, "Formato correcto", "Correcto", JOptionPane.INFORMATION_MESSAGE);
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Datos incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnValidarDocumentoIdentidad.setBounds(331, 9, 97, 25);
		contentPane.add(btnValidarDocumentoIdentidad);
		
		JButton btnValidarCorreoElectronico = new JButton("Validar");
		btnValidarCorreoElectronico.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String correoElectronico=txtCorreoElectronico.getText();
				//kevin123@gmail.com, kevin123@hotmail.com, kevin_arnold@yahoo.com, kevin@midominio.pe, correo@x7.com
				String expresionCorreoElectronico="[0-9a-zA-Z\\-_.]+@[a-zA-Z]+[a-z0-9A-Z]*.[a-zA-Z]{2,4}";
				
				if(correoElectronico.matches(expresionCorreoElectronico))
				{
					JOptionPane.showMessageDialog(null, "Formato correcto", "Correcto", JOptionPane.INFORMATION_MESSAGE);
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Datos incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnValidarCorreoElectronico.setBounds(331, 38, 97, 25);
		contentPane.add(btnValidarCorreoElectronico);
	}
}
