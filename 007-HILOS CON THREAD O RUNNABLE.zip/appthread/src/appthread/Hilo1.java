package appthread;

public class Hilo1 extends Thread{
	public void run()
	{
		try {
			Imprimir();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void Imprimir() throws InterruptedException
	{
		for(int i=0;i<50;i++)
		{
			System.out.println("Ejecutando el hilo1");
			Thread.sleep(100);
		}
	}
}
