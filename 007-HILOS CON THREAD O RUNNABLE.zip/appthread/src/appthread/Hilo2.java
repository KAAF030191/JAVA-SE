package appthread;

public class Hilo2 extends Thread{
	public void run()
	{
		try {
			Imprimir();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void Imprimir() throws InterruptedException
	{
		for(int i=0;i<50;i++)
		{
			System.out.println("Ejecutando el hilo2");
			Thread.sleep(100);
		}
	}
}
