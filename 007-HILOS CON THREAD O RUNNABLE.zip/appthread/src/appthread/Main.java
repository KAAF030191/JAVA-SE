package appthread;

public class Main {

	public static void main(String[] args)
	{
		Hilo1 hilo1=new Hilo1();
		Hilo2 hilo2=new Hilo2();
		Hilo3 hilo3=new Hilo3();
		
		hilo1.start();
		hilo2.start();		
		new Thread(hilo3).start();
	}
}