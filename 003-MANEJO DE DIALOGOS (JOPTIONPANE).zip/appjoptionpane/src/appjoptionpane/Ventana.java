package appjoptionpane;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;
import javax.swing.JButton;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;

import java.awt.event.ActionListener;
import java.util.Enumeration;
import java.awt.event.ActionEvent;

public class Ventana extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private final ButtonGroup radioGroupMensaje = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ventana frame = new Ventana();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ventana() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 381);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JRadioButton cbInformativo = new JRadioButton("Mensaje informativo");
		cbInformativo.setSelected(true);
		radioGroupMensaje.add(cbInformativo);
		cbInformativo.setBounds(8, 9, 331, 25);
		contentPane.add(cbInformativo);
		
		JRadioButton cbPeligro = new JRadioButton("Mensaje de peligro");
		radioGroupMensaje.add(cbPeligro);
		cbPeligro.setBounds(8, 39, 331, 25);
		contentPane.add(cbPeligro);
		
		JRadioButton cbError = new JRadioButton("Mensaje de error");
		radioGroupMensaje.add(cbError);
		cbError.setBounds(8, 69, 331, 25);
		contentPane.add(cbError);
		
		JRadioButton cbTextoPlano = new JRadioButton("Mensaje en texto plano");
		radioGroupMensaje.add(cbTextoPlano);
		cbTextoPlano.setBounds(8, 99, 331, 25);
		contentPane.add(cbTextoPlano);
		
		JRadioButton cbIcono = new JRadioButton("Mensaje con \u00EDcono personalizado");
		radioGroupMensaje.add(cbIcono);
		cbIcono.setBounds(8, 129, 331, 25);
		contentPane.add(cbIcono);
		
		JRadioButton cbConfirmacion = new JRadioButton("Mensaje con confirmaci\u00F3n");
		radioGroupMensaje.add(cbConfirmacion);
		cbConfirmacion.setBounds(8, 159, 331, 25);
		contentPane.add(cbConfirmacion);
		
		JRadioButton cbConfirmacionPersonalizado = new JRadioButton("Mensaje con confirmaci\u00F3n y texto personalizado");
		radioGroupMensaje.add(cbConfirmacionPersonalizado);
		cbConfirmacionPersonalizado.setBounds(8, 189, 331, 25);
		contentPane.add(cbConfirmacionPersonalizado);
		
		JRadioButton cbEntradaTexto = new JRadioButton("Mensaje con entrada de texto");
		radioGroupMensaje.add(cbEntradaTexto);
		cbEntradaTexto.setBounds(8, 219, 331, 25);
		contentPane.add(cbEntradaTexto);
		
		JRadioButton cbOpciones = new JRadioButton("Mensaje con selecci\u00F3n de opciones");
		radioGroupMensaje.add(cbOpciones);
		cbOpciones.setBounds(8, 249, 331, 25);
		contentPane.add(cbOpciones);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(8, 283, 412, 2);
		contentPane.add(separator);
		
		JButton btnLanzarMensaje = new JButton("Lanzar mensaje");
		btnLanzarMensaje.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String opcion=null;
				
				Enumeration<AbstractButton> radioMensaje=radioGroupMensaje.getElements();
				
				while (radioMensaje.hasMoreElements())
				{
					AbstractButton abstractButton = (AbstractButton) radioMensaje.nextElement();
					
					if(abstractButton.isSelected())
					{
						opcion=abstractButton.getText();
						
						break;
					}
				}
				
				switch(opcion)
				{
					case "Mensaje informativo":
						JOptionPane.showMessageDialog(null, "Mensaje de prueba", "T�tulo del mensaje", JOptionPane.INFORMATION_MESSAGE);
						
						break;
						
					case "Mensaje de peligro":
						JOptionPane.showMessageDialog(null, "Mensaje de prueba", "T�tulo del mensaje", JOptionPane.WARNING_MESSAGE);
						
						break;
						
					case "Mensaje de error":
						JOptionPane.showMessageDialog(null, "Mensaje de prueba", "T�tulo del mensaje", JOptionPane.ERROR_MESSAGE);
						
						break;
						
					case "Mensaje en texto plano":
						JOptionPane.showMessageDialog(null, "Mensaje de prueba", "T�tulo del mensaje", JOptionPane.PLAIN_MESSAGE);
						
						break;
						
					case "Mensaje con �cono personalizado":
						ImageIcon icono=new ImageIcon("D:/KAAF/Im�genes/material-design-icons-1.0.0/communication/drawable-hdpi/ic_email_black_18dp.png");
						
						JOptionPane.showMessageDialog(null, "Mensaje de prueba", "T�tulo del mensaje", JOptionPane.INFORMATION_MESSAGE, icono);
						
						break;
						
					case "Mensaje con confirmaci�n":
						int seleccion1=JOptionPane.showConfirmDialog(null, "Mensaje de prueba", "T�tulo del mensaje", JOptionPane.YES_NO_OPTION);
						
						JOptionPane.showMessageDialog(null, seleccion1);
						
						break;
						
					case "Mensaje con confirmaci�n y texto personalizado":
						Object[] textoBotones={"Confirmar", "Rechazar"};
						
						int seleccion2=JOptionPane.showOptionDialog(null, "Mensaje de prueba", "T�tulo del mensaje", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, textoBotones, textoBotones[0]);
						
						JOptionPane.showMessageDialog(null, seleccion2);
						
						break;
						
					case "Mensaje con entrada de texto":
						String textoEntrada1=(String)JOptionPane.showInputDialog(null, "Mensaje de prueba", "T�tulo del mensaje", JOptionPane.INFORMATION_MESSAGE, null, null, null);
						
						JOptionPane.showMessageDialog(null, textoEntrada1);
						
						break;
						
					case "Mensaje con selecci�n de opciones":
						Object[] opcionesTexto={"Valor 1", "Valor 2", "Valor 3"};
						
						String textoEntrada2=(String)JOptionPane.showInputDialog(null, "Mensaje de prueba", "T�tulo del mensaje", JOptionPane.INFORMATION_MESSAGE, null, opcionesTexto, opcionesTexto[1]);
						
						JOptionPane.showMessageDialog(null, textoEntrada2);
						
						break;
				}
			}
		});
		btnLanzarMensaje.setBounds(218, 298, 202, 25);
		contentPane.add(btnLanzarMensaje);
	}
}
