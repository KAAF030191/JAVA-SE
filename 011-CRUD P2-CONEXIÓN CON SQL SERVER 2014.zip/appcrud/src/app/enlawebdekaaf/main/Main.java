package app.enlawebdekaaf.main;

import app.enlawebdekaaf.conexion.Conexion;

public class Main
{
	public static void main(String[] args)
	{
		if(Conexion.getConnection()!=null)
		{
			System.out.println("Conexi�n exitosa.");
		}
		else
		{
			System.out.println("Hubo un error en la conexi�n a la base de datos.");
		}
	}
}