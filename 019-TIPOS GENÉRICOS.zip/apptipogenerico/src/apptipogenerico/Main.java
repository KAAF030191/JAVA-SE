package apptipogenerico;

public class Main {
	public static void main(String[] args)
	{
		DaoPersona daoPersona=new DaoPersona();
		
		daoPersona.insert(null);
		
		DaoVenta daoVenta=new DaoVenta();
		
		daoVenta.insert(null);
	}
}