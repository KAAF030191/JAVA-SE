package apptipogenerico;

import java.util.List;

public interface GenericDao<T>
{
	public boolean insert(T objeto);
	public boolean edit(T objeto);
	public T getById(String id);
	public List<T> getAll();
}