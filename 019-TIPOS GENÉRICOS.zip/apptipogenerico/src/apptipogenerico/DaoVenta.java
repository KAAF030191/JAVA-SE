package apptipogenerico;

import java.util.List;

public class DaoVenta implements GenericDao<Venta>
{
	@Override
	public boolean insert(Venta objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean edit(Venta objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Venta getById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Venta> getAll() {
		// TODO Auto-generated method stub
		return null;
	}
}