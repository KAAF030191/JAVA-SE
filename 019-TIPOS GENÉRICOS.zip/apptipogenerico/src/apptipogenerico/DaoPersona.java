package apptipogenerico;

import java.util.List;

public class DaoPersona implements GenericDao<Persona>
{
	@Override
	public boolean insert(Persona objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean edit(Persona objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Persona getById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Persona> getAll() {
		// TODO Auto-generated method stub
		return null;
	}
}